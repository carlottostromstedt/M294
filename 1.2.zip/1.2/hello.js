document.addEventListener("DOMContentLoaded", (event) => {
    var button = document.getElementById("click-me")
    button.addEventListener("click", function() {
        alert("Hallo Welt")
    });
});

